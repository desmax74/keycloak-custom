package com.dell.api.client.sample;

/**
 * This class shows how to write a pure REST client to call the REST services secured by Keycloak.
 * 
 * Our OAuth client name is "admin-client". Our realm name is "DSG_API".
 */

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.entity.StringEntity;

import org.keycloak.OAuth2Constants;
import org.keycloak.ServiceUrlConstants;
import org.keycloak.representations.AccessTokenResponse;
import org.keycloak.util.JsonSerialization;
import org.keycloak.util.KeycloakUriBuilder;
import org.json.*;

public class ApacheHttpTestClient {
	private String tokenString;
	
	private String hostname = "ec2-54-165-240-107.compute-1.amazonaws.com";

	public ApacheHttpTestClient() {
	}
	
	public String getAccessToken() {
		return tokenString;
	}
	
	public void getToken(String userid, String password) throws IOException {

		HttpClient client = new org.keycloak.adapters.HttpClientBuilder().disableTrustManager().build();

		try {
			String uri = "http://" + hostname + ":8080/auth";
			System.out.println(uri);
			
			HttpPost post = new HttpPost(KeycloakUriBuilder
					.fromUri(uri)
					.path(ServiceUrlConstants.TOKEN_SERVICE_DIRECT_GRANT_PATH)
					.build("DSG_API"));

			List<NameValuePair> formparams = new ArrayList<NameValuePair>();
			formparams.add(new BasicNameValuePair("username", userid));
			formparams.add(new BasicNameValuePair("password", password));
			formparams.add(new BasicNameValuePair(OAuth2Constants.CLIENT_ID,"admin-client"));
			UrlEncodedFormEntity form = new UrlEncodedFormEntity(formparams,"UTF-8");
			post.setEntity(form);

			HttpResponse response = client.execute(post);
			int status = response.getStatusLine().getStatusCode();
			HttpEntity entity = response.getEntity();
			
			if (status != 200) {
				throw new IOException("Bad status: " + status);
			}
			if (entity == null) {
				throw new IOException("No Entity");
			}
			
			InputStream is = entity.getContent();
			try {
				ByteArrayOutputStream os = new ByteArrayOutputStream();
				int c;
				while ((c = is.read()) != -1) {
					os.write(c);
				}
				byte[] bytes = os.toByteArray();
				String json = new String(bytes);
				
				try {
					AccessTokenResponse res = JsonSerialization.readValue(json, AccessTokenResponse.class);
					tokenString = res.getToken();
					
				} catch (IOException e) {
					throw new IOException(json, e);
				}
			} finally {
				try {
					is.close();
				} catch (IOException ignored) {

				}
			}
		} finally {
			
		}
	}

	/**
	 * Demonstrate unsecure http query all 
	 *   http://localhost:8080/v1/cloudproviders
	 */
	public void getCloudProviders(String format)  {
		
		httpget("/cloudproviders", format, false);
	}
	
	/**
	 * Demonstrate unsecure http query by id
	 *   http://localhost:8080/v1/cloudproviders/1
	 */
	public void getCloudProvidersById(String format) {
		
		httpget("/cloudproviders/1", format, false);
	}
	
	/**
	 * Demonstrate unsecure http query by parameters (e.g. name)
	 *   http://localhost:8080/v1/cloudproviders?name=AWS
	 */
	public void getCloudProvidersByName(String format) {
		
		httpget("/cloudproviders?name=AWS", format, false);
	}
	
	/**
	 * Demonstrate secure http query all
	 *  http://localhost:8080/v1/blueprints
	 */
	public void getBlueprints(String format)  {
		
		httpget("/blueprints", format, true);
	}
	
	/**
	 * Demonstrate secure http query by id
	 *  http://localhost:8080/v1/blueprints/1234
	 */
	public void getBlueprintsById(String format) {
		
		httpget("/blueprints/1", format, true);
	}
	
	/**
	 * Demonstrate secure http query by name
	 *   http://localhost:8080/v1/blueprints?name=AWS
	 */
	public void getBlueprintsByName(String format) {
		
		httpget("/blueprints?name=Wordpress", format, true);
	}
	
	/**
	 * Demonstrate secure http post
	 *   http://localhost:8080/v1/isvblueprint
	 */
	public void addISVBlueprint(String format) {
		
		StringEntity se;
		
		try {
			if (format.equals("application/json")) {
			
			JSONObject json = new JSONObject();     
			json.put("name", "Mongodb");
			json.put("id", "100");
	   
			se = new StringEntity(json.toString());

			}
			else {
				String xml = "<Blueprint name=\"Mongodb\" id=\"100\"/>";
				
				se = new StringEntity(xml);

			}
			
			se.setContentEncoding("UTF-8");
			se.setContentType(format);
			httppost("/isvblueprint", format, se);	
		}
		catch (Exception ex) {
			
		}
	}
	
	/**
	 * Demonstrate secure http put
	 *   http://localhost:8080/v1/isvblueprint/10
	 */
	public void updateISVBlueprint(String format) {
		
		StringEntity se;
		
		try {
			if (format.equals("application/json")) {
			
				JSONObject json = new JSONObject();     
				json.put("id", "100");
	   
				se = new StringEntity(json.toString());
			}
			else {
				String xml = "<Blueprint id=\"100\"/>";
				
				se = new StringEntity(xml);
			}
			
			se.setContentEncoding("UTF-8");
			se.setContentType(format);
			httpput("/isvblueprint/10", format, se);	
		}
		catch (Exception ex) {
			
		}
	}
	
	/**
	 * Demonstrate secure http delete
	 *   http://localhost:8080/v1/isvblueprint/10
	 */
	public void deleteISVBlueprint(String format) {
		StringEntity se;
		
		try {
			if (format.equals("application/json")) {
			
				JSONObject json = new JSONObject();     
				json.put("id", "100");
	   
				se = new StringEntity(json.toString());
			}
			else {
				String xml = "<Blueprint id=\"100\"/>";
				
				se = new StringEntity(xml);
			}
			
			se.setContentEncoding("UTF-8");
			se.setContentType(format);
			httpdelete("/isvblueprint/10", format, se);	
		}
		catch (Exception ex) {
			
		}
	}
	
	private void httppost(String url, String format, StringEntity se) {
			
		try {
			HttpPost httppost = new HttpPost(composeURL(url));
			
			httppost.setHeader("Accept", format);
			httppost.setHeader("Authorization", "Bearer " + getAccessToken());
			
		    httppost.setEntity(se);      
			
			HttpClient httpclient = HttpClientBuilder.create().build(); 
	
			HttpResponse response = httpclient.execute(httppost);

			System.out.println(response.getStatusLine().toString());	
			print(response.getEntity().getContent());
			

		} catch (Exception e) {

			e.printStackTrace();
		}
	}
	
	private void httpget(String url, String format, Boolean secure) {
		
		try {
			
			HttpGet get = new HttpGet(composeURL(url));
			
			get.setHeader("Accept", format);
			
			if (secure) {	
				get.setHeader("Authorization", "Bearer " + getAccessToken());
			}
			
			HttpClient httpclient = HttpClientBuilder.create().build(); 
	
			HttpResponse response = httpclient.execute(get);
			
			System.out.println(response.getStatusLine().toString());	
			print(response.getEntity().getContent());
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void httpput(String url, String format, StringEntity se) {
		
		try {
			
			HttpPut httpput = new HttpPut(composeURL(url));
			httpput.setHeader("Accept", format);
			httpput.setHeader("Authorization", "Bearer " + getAccessToken());

			HttpClient httpclient = HttpClientBuilder.create().build(); 
	
			HttpResponse response = httpclient.execute(httpput);
			
			System.out.println(response.getStatusLine().toString());	
			print(response.getEntity().getContent());
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void httpdelete(String url, String format, StringEntity se) {
		
		try {
			
			HttpDelete httpdelete = new HttpDelete(composeURL(url));
			httpdelete.setHeader("Accept", format);
			httpdelete.setHeader("Authorization", "Bearer " + getAccessToken());

			HttpClient httpclient = HttpClientBuilder.create().build(); 
	
			HttpResponse response = httpclient.execute(httpdelete);
			
			System.out.println(response.getStatusLine().toString());	
			print(response.getEntity().getContent());
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}	
	
	
	private String composeURL(String url) {
		
		String baseURL = "http://" + hostname + ":8080/dsgapi";
		 
		url = baseURL + url;
		System.out.println(url);
		return url;
	}
	
	
	private void print(InputStream is) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(is));
        for (String l = br.readLine(); l != null; l = br.readLine()) {
            System.out.println(l);
        }
    }
	
	
	public void runTests() {
		
		System.out.println("Token: " + getAccessToken());
		System.out.println("\n");
		
		//
		// Demonstrate none secure GET calls
		//
		getCloudProviders("application/json");
		getCloudProviders("application/xml");
		System.out.println("\n");
		
		//
		// Demonstrate secure GET calls
		//
		getBlueprints("application/json");
		getBlueprints("application/xml");
		System.out.println("\n");
		
		getBlueprintsById("application/json");
		getBlueprintsById("application/xml");
		System.out.println("\n");	
		
		getBlueprintsByName("application/json");
		getBlueprintsByName("application/xml");
		System.out.println("\n");
		
		//
		// Demonstrate Partner Role - only authorized partner can post/update/delete blueprints
		//
		System.out.println("......Testing Post.........");
		addISVBlueprint("application/json");
		addISVBlueprint("application/xml");
		System.out.println("\n");
		
		System.out.println("......Testing Put.........");
		updateISVBlueprint("application/json");
		updateISVBlueprint("application/xml");
		System.out.println("\n");
		
		System.out.println("......Testing Delete.........");
		deleteISVBlueprint("application/json");
		deleteISVBlueprint("application/xml");	
		System.out.println("\n");
	}
	
	public static void main(String[] args) throws Exception {

		ApacheHttpTestClient testclient = new ApacheHttpTestClient();
		
		//
		// Roger has user role, he cannot call the post/put/delete example
		//
		System.out.println("---- Logging in as roger-----------");
		testclient.getToken("roger","password");
		testclient.runTests();
		
		//
		// Andy has both isv and user role, so he can call post/put/delete examples
		//
		System.out.println("\n\n---- Logging in as andy-----------");
		testclient.getToken("andy","password");
		testclient.runTests();
	}
}
